"""
AutoValue AI - Used Car Valuation App

Streamlit front-end that:
1. Collects vehicle details from the user
2. Predicts fair market value with a pre-trained sklearn pipeline
   (car_price_pipeline.pkl: OneHotEncoder -> PolynomialFeatures -> LinearRegression)
3. Compares the estimate against the seller's asking price
4. Summarizes depreciation vs. the original purchase price
5. Asks an LLM (via ai_analysis.analyze_car) for a plain-English recommendation
"""

import joblib
import pandas as pd
import streamlit as st

from ai_analysis import analyze_car

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

DATA_PATH = "car_data.csv"
PIPELINE_PATH = "car_price_pipeline.pkl"

# Columns the trained pipeline was fit on, in this exact order.
MODEL_FEATURES = [
    "Brand",
    "Model",
    "Car_Type",
    "Transmission",
    "Fuel_Type",
    "Age_Years",
    "No_of_Owners",
    "KM_Driven",
]

st.set_page_config(
    page_title="AutoValue AI",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="expanded",
)


# --------------------------------------------------------------------------
# Styling
# --------------------------------------------------------------------------

def inject_css() -> None:
    st.markdown(
        """
        <style>
        .stApp { background-color: #F5F7FA; }

        .block-container { padding-top: 2rem; padding-bottom: 2rem; }

        .stButton>button {
            background-color: #2563EB;
            color: white;
            border-radius: 12px;
            border: none;
            height: 50px;
            width: 100%;
            font-size: 18px;
            font-weight: 600;
        }
        .stButton>button:hover { background-color: #1E40AF; }

        [data-testid="stMetric"] {
            background: white;
            padding: 18px;
            border-radius: 15px;
            box-shadow: 0px 3px 10px rgba(0,0,0,0.08);
        }

        section[data-testid="stSidebar"] { background-color: #FFFFFF; }
        .stNumberInput { background: white; }
        </style>
        """,
        unsafe_allow_html=True,
    )


# --------------------------------------------------------------------------
# Cached loaders
# --------------------------------------------------------------------------

@st.cache_resource(show_spinner=False)
def load_pipeline():
    return joblib.load(PIPELINE_PATH)


@st.cache_data(show_spinner=False)
def load_reference_data() -> pd.DataFrame:
    return pd.read_csv(DATA_PATH)


# --------------------------------------------------------------------------
# UI sections
# --------------------------------------------------------------------------

def render_header() -> None:
    st.title("AutoValue AI")
    st.markdown(
        """
        ### AI-Powered Used Car Valuation Platform

        Estimate a vehicle's fair market value using Machine Learning and receive
        AI-powered buying recommendations in seconds.
        """
    )


def render_sidebar() -> None:
    st.sidebar.title("About")
    st.sidebar.info(
        """
        This project predicts the market value of used cars using a
        scikit-learn pipeline (categorical encoding + polynomial regression)
        trained on real listing data. See `eda.ipynb` for the full
        exploratory analysis and evaluation metrics.
        """
    )


def render_hero_image() -> None:
    st.markdown(
        """
        <div style="height:430px; overflow:hidden; border-radius:20px;">
        <img src="https://www.gethow.org/wp-content/uploads/2019/06/resale-car-1000x487.jpg"
             style="width:100%; height:100%; object-fit:cover;">
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_vehicle_form(df: pd.DataFrame) -> dict:
    """Collect vehicle details and return them as a plain dict."""
    st.subheader("Vehicle Details")

    brands = sorted(df["Brand"].unique())
    brand = st.selectbox("Brand", brands)

    models_for_brand = sorted(df.loc[df["Brand"] == brand, "Model"].unique())
    model_name = st.selectbox("Model", models_for_brand)

    car_type = st.selectbox("Car Type", sorted(df["Car_Type"].unique()))
    transmission = st.selectbox("Transmission", sorted(df["Transmission"].unique()))
    fuel_type = st.selectbox("Fuel Type", sorted(df["Fuel_Type"].unique()))

    col1, col2 = st.columns(2)
    with col1:
        age = st.number_input("Age (Years)", min_value=0, max_value=40, value=5)
        owners = st.number_input("Number of Previous Owners", min_value=1, max_value=10, value=1)
    with col2:
        mileage = st.number_input("Mileage (KM)", min_value=0, value=60000, step=1000)
        original_price = st.number_input(
            "Original Price (USD)", min_value=0, value=30000, step=500
        )

    seller_price = st.number_input(
        "Seller Asking Price (Optional, USD)", min_value=0, value=0, step=500
    )

    analyze = st.button("Analyze Vehicle")

    return {
        "brand": brand,
        "model_name": model_name,
        "car_type": car_type,
        "transmission": transmission,
        "fuel_type": fuel_type,
        "age": age,
        "owners": owners,
        "mileage": mileage,
        "original_price": original_price,
        "seller_price": seller_price,
        "analyze": analyze,
    }


# --------------------------------------------------------------------------
# Prediction & analysis
# --------------------------------------------------------------------------

def predict_price(pipeline, details: dict) -> float:
    row = pd.DataFrame(
        [{
            "Brand": details["brand"],
            "Model": details["model_name"],
            "Car_Type": details["car_type"],
            "Transmission": details["transmission"],
            "Fuel_Type": details["fuel_type"],
            "Age_Years": details["age"],
            "No_of_Owners": details["owners"],
            "KM_Driven": details["mileage"],
        }]
    )[MODEL_FEATURES]

    return float(pipeline.predict(row)[0])


def render_prediction(estimated_price: float) -> None:
    st.subheader("📊 Prediction")
    st.metric(label="Estimated Market Price (USD)", value=f"${estimated_price:,.2f}")


def render_deal_analysis(estimated_price: float, seller_price: float) -> None:
    if seller_price <= 0:
        return  # No asking price entered - nothing to compare against.

    st.subheader("💰 Deal Analysis")
    difference = estimated_price - seller_price

    col1, col2 = st.columns(2)
    with col1:
        st.metric(label="Seller Asking Price (USD)", value=f"${seller_price:,.2f}")
    with col2:
        if estimated_price > seller_price:
            st.metric(label="Potential Savings", value=f"${difference:,.2f}")
        else:
            st.metric(label="Extra Cost", value=f"${-difference:,.2f}")

    if difference > 1000:
        st.success("Great Deal! The asking price is below the estimated market value.")
    elif -1000 <= difference <= 1000:
        st.warning("Fair Price. The asking price is close to the estimated market value.")
    else:
        st.error("Overpriced. Consider negotiating.")


def render_depreciation_summary(original_price: float, estimated_price: float) -> float:
    st.subheader("📉 Depreciation Summary")
    value_lost = original_price - estimated_price
    depreciation = (value_lost / original_price * 100) if original_price > 0 else 0.0

    st.write(f"Original Price: ${original_price:,.2f}")
    st.write(f"Estimated Current Price: ${estimated_price:,.2f}")
    st.write(f"Value Lost: ${value_lost:,.2f}")
    st.write(f"Depreciation: {depreciation:.2f}%")

    return depreciation


def render_ai_analysis(details: dict, estimated_price: float, depreciation: float) -> None:
    with st.spinner("Getting AI recommendation..."):
        ai_response = analyze_car(
            age=details["age"],
            mileage=details["mileage"],
            original_price=details["original_price"],
            predicted_price=estimated_price,
            seller_price=details["seller_price"],
            depreciation=depreciation,
        )

    st.divider()
    st.subheader("🤖 AI Vehicle Analysis")
    st.write(ai_response)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main() -> None:
    inject_css()
    render_header()
    render_sidebar()

    pipeline = load_pipeline()
    reference_data = load_reference_data()

    left, right = st.columns([1, 1])
    with left:
        render_hero_image()
    with right:
        details = render_vehicle_form(reference_data)

    if not details["analyze"]:
        return

    estimated_price = predict_price(pipeline, details)

    render_prediction(estimated_price)
    render_deal_analysis(estimated_price, details["seller_price"])
    depreciation = render_depreciation_summary(details["original_price"], estimated_price)

    try:
        render_ai_analysis(details, estimated_price, depreciation)
    except Exception as exc:  # e.g. missing/invalid GEMINI_API_KEY
        st.divider()
        st.subheader("🤖 AI Vehicle Analysis")
        st.error(f"AI analysis is currently unavailable: {exc}")


if __name__ == "__main__":
    main()